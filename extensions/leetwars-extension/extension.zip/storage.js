const STORAGE_KEY = "leetwars_extension_state_v1";
export async function loadState() {
    const res = await chrome.storage.local.get(STORAGE_KEY);
    const raw = res?.[STORAGE_KEY];
    if (raw && typeof raw === "object") {
        return {
            jobs: Array.isArray(raw.jobs) ? raw.jobs : [],
            backendToken: raw.backendToken,
            backendUrl: raw.backendUrl,
            leetcodeUsername: raw.leetcodeUsername,
            email: raw.email,
            name: raw.name
        };
    }
    return { jobs: [] };
}
export async function saveState(next) {
    const current = await loadState();
    const merged = { ...current, ...next };
    await chrome.storage.local.set({
        [STORAGE_KEY]: merged,
    });
}
