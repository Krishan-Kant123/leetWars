import { loadState } from "./storage.js";
import { fetchActiveContests } from "./backendClient.js";
const FRONTEND_URL = "https://leetwars.vercel.app/login";
document.addEventListener("DOMContentLoaded", async () => {
    const loadingDiv = document.getElementById("loading");
    const authDiv = document.getElementById("authenticated");
    const unauthDiv = document.getElementById("unauthenticated");
    const usernameSpan = document.getElementById("username");
    const loginBtn = document.getElementById("login-btn");
    const contestsLoading = document.getElementById("contests-loading");
    const contestsList = document.getElementById("contests-list");
    if (loginBtn) {
        loginBtn.addEventListener("click", () => {
            chrome.tabs.create({ url: FRONTEND_URL });
        });
    }
    try {
        const state = await loadState();
        console.log("Extension state loaded:", state);
        if (loadingDiv)
            loadingDiv.classList.add("hidden");
        // Check if we have auth tokens saved
        const backendToken = state.backendToken;
        const leetcodeUsername = state.leetcodeUsername;
        const name = state.name;
        const email = state.email;
        if (backendToken) {
            if (authDiv)
                authDiv.classList.remove("hidden");
            if (usernameSpan) {
                if (leetcodeUsername) {
                    usernameSpan.textContent = leetcodeUsername;
                    usernameSpan.classList.add("success");
                    usernameSpan.classList.remove("error");
                }
                else {
                    usernameSpan.textContent = `No LC Username Set! (Logged in as ${name || email})`;
                    usernameSpan.classList.remove("success");
                    usernameSpan.classList.add("error");
                }
            }
            // Render jobs
            const jobsList = document.getElementById("jobs-list");
            if (jobsList) {
                const jobs = Array.isArray(state.jobs) ? state.jobs.slice().reverse() : [];
                if (jobs.length === 0) {
                    jobsList.innerHTML = "<span style='color: #64748b;'>No submissions captured yet.</span>";
                }
                else {
                    jobsList.innerHTML = jobs.map((j) => {
                        const time = new Date(j.createdAtMs).toLocaleTimeString();
                        let color = "#94a3b8"; // default
                        if (j.status === "RECORDED")
                            color = "#4ade80";
                        if (j.status === "FAILED" || j.status === "IGNORED")
                            color = "#f87171";
                        if (j.status === "POLLING" || j.status === "CAPTURED")
                            color = "#fbbf24";
                        let extra = j.status;
                        if (j.error)
                            extra += ` - ${j.error}`;
                        else if (j.titleSlug)
                            extra += ` - ${j.titleSlug} (${j.accepted ? 'Accepted' : 'Failed'})`;
                        return `<div style="margin-bottom: 6px; border-bottom: 1px solid #334155; padding-bottom: 4px;">
              <strong style="color: ${color};">${j.submissionId}</strong> [${time}]<br/>
              <span style="color: #cbd5e1;">${extra}</span>
            </div>`;
                    }).join("");
                }
            }
            // Fetch and render active contests
            if (contestsList && contestsLoading) {
                try {
                    const activeContests = await fetchActiveContests();
                    contestsLoading.classList.add("hidden");
                    if (activeContests.length === 0) {
                        contestsList.innerHTML = "<span style='color: #64748b; font-size: 12px;'>No active contests found.</span>";
                    }
                    else {
                        contestsList.innerHTML = activeContests.map((c) => {
                            return `
                <div class="contest-card">
                  <div class="contest-name">${c.name}</div>
                  <div class="contest-stats">
                    <span>Score: <span class="stat-val">${c.score}</span></span>
                    <span>Penalty: <span class="stat-val">${c.total_penalty}m</span></span>
                    <span>Accepted: <span class="stat-val">${c.accepted_count}/${c.total_problems}</span></span>
                  </div>
                </div>
              `;
                        }).join("");
                    }
                }
                catch (err) {
                    contestsLoading.textContent = "Failed to load active contests.";
                }
            }
        }
        else {
            if (unauthDiv)
                unauthDiv.classList.remove("hidden");
        }
    }
    catch (error) {
        console.error("Error loading state:", error);
        if (loadingDiv) {
            loadingDiv.textContent = "Error loading extension state.";
        }
    }
});
