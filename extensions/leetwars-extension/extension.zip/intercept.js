/**
 * This script runs in the MAIN world, meaning it shares the execution environment
 * with LeetCode. It can monkey-patch window.fetch.
 */
(function initSubmitInterception() {
    if (window.__leetwars_fetch_patched)
        return;
    window.__leetwars_fetch_patched = true;
    const isLeetCodeSubmitUrl = (url) => {
        return /\/problems\/[^/]+\/submit\/?$/.test(url);
    };
    const originalFetch = window.fetch;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const overriddenFetch = (async (...args) => {
        const [resource, init] = args;
        const url = typeof resource === "string" ? resource : resource.toString();
        if (isLeetCodeSubmitUrl(url)) {
            const res = await originalFetch(resource, init);
            try {
                const cloned = res.clone();
                const data = await cloned.json();
                const submissionId = data?.submission_id;
                if (typeof submissionId === "number" || (typeof submissionId === "string" && submissionId.trim())) {
                    const n = Number(submissionId);
                    if (Number.isFinite(n)) {
                        // Forward to ISOLATED world content script
                        window.postMessage({
                            type: "LEETWARS_SUBMISSION_RELAY",
                            payload: { submissionId: n, submissionUrl: url },
                        }, "*");
                    }
                }
            }
            catch {
                // ignore
            }
            return res;
        }
        return originalFetch(resource, init);
    });
    window.fetch = overriddenFetch;
    // XHR fallback
    const OriginalXHR = window.XMLHttpRequest;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    window.XMLHttpRequest = function (...rest) {
        const xhr = new OriginalXHR(...rest);
        const originalOpen = xhr.open.bind(xhr);
        xhr.open = (method, url, async, user, password) => {
            xhr.__leetwars_submit_url__ = typeof url === "string" ? url : String(url);
            xhr.__leetwars_method__ = method;
            return originalOpen(method, url, async, user, password);
        };
        xhr.addEventListener("load", () => {
            const url = xhr.__leetwars_submit_url__;
            const method = xhr.__leetwars_method__;
            if (method === "POST" && typeof url === "string" && isLeetCodeSubmitUrl(url)) {
                try {
                    const bodyText = xhr.responseText;
                    if (!bodyText)
                        return;
                    const data = JSON.parse(bodyText);
                    const submissionId = data?.submission_id;
                    if (typeof submissionId === "number") {
                        window.postMessage({
                            type: "LEETWARS_SUBMISSION_RELAY",
                            payload: { submissionId, submissionUrl: url },
                        }, "*");
                    }
                }
                catch {
                    // ignore
                }
            }
        });
        return xhr;
    };
})();

